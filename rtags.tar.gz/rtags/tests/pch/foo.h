#ifndef FOO_H
#define FOO_H

#ifdef __cplusplus
extern "C"
#endif
void foo();

#endif
