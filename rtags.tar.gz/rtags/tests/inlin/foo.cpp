#include "foo.h"

void Foo::foo()
{
    func();
}

