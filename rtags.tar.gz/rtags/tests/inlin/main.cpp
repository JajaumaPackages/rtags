#include "header.h"

int main()
{
    func();
}
