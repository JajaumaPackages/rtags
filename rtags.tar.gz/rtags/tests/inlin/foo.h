#ifndef foo_h
#define foo_h

#include "header.h"
class Foo
{
public:
    Foo()
    {
        func();
    }

    void foo();
};

#endif
