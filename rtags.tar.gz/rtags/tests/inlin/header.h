#ifndef header_h
#define header_h

static inline void func()
{

}


static inline void func2()
{
    func();
}

#endif
