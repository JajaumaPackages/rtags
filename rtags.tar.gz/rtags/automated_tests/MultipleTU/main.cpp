#include "a.hpp"

void foo() {
    free_function();
    free_function();
}

