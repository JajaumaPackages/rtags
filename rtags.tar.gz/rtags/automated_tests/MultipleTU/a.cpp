#include "a.hpp"

void free_function() {}

void caller() {
    free_function();
}
