#pragma once
struct ForwardDecl;
struct Local { ForwardDecl* m; };
